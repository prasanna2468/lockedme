import Welcome.Welcome;

public class LockedMeApplications {
    public static void main(String[] args) {
        Welcome welcome = new Welcome();
        welcome.introScreen();
        welcome.GetUserInput();
    }
}





