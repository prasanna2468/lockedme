package Services;

import MainMenu.FileOptions;

public class DashboardService {

    public static void setCurrentScreen()   {
        FileOptions file = new FileOptions();
        file.GetUserInput();
    }
}